# Gitea Robot - Issue Graph & PageRank for Gitea

## Overview

Gitea Robot adds issue dependency tracking and PageRank-based prioritization to Gitea, enabling AI agents to make intelligent task selection decisions.

## Features

- **Issue Dependencies**: Track blocking relationships between issues
- **PageRank Calculation**: Automatically prioritize issues based on dependency graph
- **Agent API**: REST endpoints optimized for AI agent consumption
- **Feature Flag**: Can be enabled/disabled per instance

## Quick Start

### 1. Download

```bash
wget https://git.terraphim.cloud/terraphim/gitea/releases/download/v1.26.0-robot/gitea-robot-linux-amd64
chmod +x gitea-robot-linux-amd64
```

### 2. Configure

Create `app.ini`:

```ini
[server]
HTTP_PORT = 3000

[database]
DB_TYPE = sqlite3
PATH = ./gitea.db

[issue_graph]
ENABLED = true
DAMPING_FACTOR = 0.85
ITERATIONS = 100
```

### 3. Run

```bash
export GITEA_I_AM_BEING_UNSAFE_RUNNING_AS_ROOT=true  # Only if running as root
./gitea-robot-linux-amd64 web --config app.ini
```

### 4. Use the API

```bash
export GITEA_TOKEN=your_api_token
export GITEA_URL=http://localhost:3000

# Get prioritized task list
curl -H "Authorization: token $GITEA_TOKEN" \
  "$GITEA_URL/api/v1/robot/triage?owner=terraphim&repo=gitea"
```

## API Endpoints

### GET /api/v1/robot/triage

Returns prioritized list of issues for agents.

**Query Parameters:**
- `owner` (required): Repository owner
- `repo` (required): Repository name

**Response:**
```json
{
  "quick_ref": {
    "total": 42,
    "open": 12
  },
  "recommendations": [
    {
      "id": 123,
      "index": 42,
      "title": "Implement authentication",
      "pagerank": 0.85,
      "status": "open"
    }
  ],
  "project_health": {
    "avg_pagerank": 0.34,
    "max_pagerank": 0.85
  }
}
```

### GET /api/v1/robot/ready

Returns issues with no open blockers.

### GET /api/v1/robot/graph

Returns the dependency graph.

## CLI Tool

The `gitea-robot` CLI provides a convenient wrapper:

```bash
# Setup
export GITEA_URL=http://localhost:3000
export GITEA_TOKEN=your_token

# Get triage report
./gitea-robot triage --owner terraphim --repo gitea

# Get ready issues
./gitea-robot ready --owner terraphim --repo gitea

# Get dependency graph
./gitea-robot graph --owner terraphim --repo gitea
```

## Configuration

### Feature Flag

Enable/disable issue graph features:

```ini
[issue_graph]
ENABLED = true
DAMPING_FACTOR = 0.85  # PageRank damping factor
ITERATIONS = 100       # PageRank iteration count
```

### Database

Supports SQLite, MySQL, and PostgreSQL:

```ini
[database]
DB_TYPE = sqlite3
PATH = ./gitea.db
```

## Building from Source

```bash
git clone https://git.terraphim.cloud/terraphim/gitea.git
cd gitea
make build
```

For SQLite support:
```bash
CGO_ENABLED=1 go build -tags 'sqlite sqlite_unlock_notify' -o gitea
```

## Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Agent/CLI     │────▶│   Gitea API     │────▶│   Robot Service │
│                 │     │                 │     │                 │
│ gitea-robot     │     │ /robot/triage   │     │ PageRank calc   │
│                 │     │ /robot/ready    │     │ Graph cache     │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                                                         │
                                                         ▼
                                                  ┌─────────────────┐
                                                  │   Database      │
                                                  │                 │
                                                  │ graph_cache     │
                                                  │ issue_dependency│
                                                  └─────────────────┘
```

## Comparison with Beads

| Feature | Beads | Gitea Robot |
|---------|-------|-------------|
| Storage | SQLite + JSONL | Gitea database |
| Web UI | ❌ | ✅ (Gitea native) |
| Multi-user | ❌ | ✅ |
| PageRank | ✅ | ✅ |
| Git integration | JSONL in repo | Native |
| API | CLI | REST |

## License

MIT - Same as Gitea

## Repository

https://git.terraphim.cloud/terraphim/gitea