# Installation Guide

## System Requirements

- Linux (amd64)
- 512MB RAM minimum
- 1GB disk space

## Install

### 1. Download Release

```bash
wget https://git.terraphim.cloud/terraphim/gitea/releases/download/v1.26.0-robot/gitea-robot-linux-amd64
wget https://git.terraphim.cloud/terraphim/gitea/releases/download/v1.26.0-robot/gitea-robot
chmod +x gitea-robot-linux-amd64 gitea-robot
```

### 2. Create Directories

```bash
mkdir -p /var/lib/gitea/{data,custom}
mkdir -p /etc/gitea
```

### 3. Configuration

Create `/etc/gitea/app.ini`:

```ini
APP_NAME = Gitea Robot
RUN_USER = git
WORK_PATH = /var/lib/gitea

[repository]
ROOT = /var/lib/gitea/data/repositories

[server]
PROTOCOL = http
DOMAIN = localhost
HTTP_PORT = 3000
ROOT_URL = http://localhost:3000/

[database]
DB_TYPE = sqlite3
PATH = /var/lib/gitea/data/gitea.db

[session]
PROVIDER_CONFIG = /var/lib/gitea/data/sessions

[picture]
AVATAR_UPLOAD_PATH = /var/lib/gitea/data/avatars
REPOSITORY_AVATAR_UPLOAD_PATH = /var/lib/gitea/data/repo-avatars

[attachment]
PATH = /var/lib/gitea/data/attachments

[log]
MODE = console
LEVEL = Info
ROOT_PATH = /var/lib/gitea/log

[security]
INSTALL_LOCK = true

[issue_graph]
ENABLED = true
DAMPING_FACTOR = 0.85
ITERATIONS = 100
```

### 4. Systemd Service

Create `/etc/systemd/system/gitea-robot.service`:

```ini
[Unit]
Description=Gitea Robot
After=network.target

[Service]
Type=simple
User=git
Group=git
WorkingDirectory=/var/lib/gitea
ExecStart=/usr/local/bin/gitea-robot-linux-amd64 web --config /etc/gitea/app.ini
Restart=always
Environment=USER=git HOME=/home/git GITEA_WORK_DIR=/var/lib/gitea

[Install]
WantedBy=multi-user.target
```

### 5. Start Service

```bash
useradd -r -m -d /home/git -s /bin/bash git
chown -R git:git /var/lib/gitea

systemctl daemon-reload
systemctl enable gitea-robot
systemctl start gitea-robot
```

### 6. Verify

```bash
curl http://localhost:3000/api/v1/version
```

## First Time Setup

1. Open http://localhost:3000 in browser
2. Register admin account
3. Create repository
4. Enable issue tracking in repo settings
5. Create issues with dependencies
6. Test API: `curl http://localhost:3000/api/v1/robot/triage?owner=USER&repo=REPO`